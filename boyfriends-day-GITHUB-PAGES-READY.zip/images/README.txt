Your photos are already added as photo1.jpg through photo9.jpg.
photo1.jpg is the pink-shirt photo you specified.
