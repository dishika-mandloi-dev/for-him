The site now embeds the official YouTube release of “Khayaal” by Arijit Anand & Ankita Barwad, so no copyrighted MP3 is bundled.
If you own/have permission to use an MP3, you can still add it here and wire it into the local player later.
