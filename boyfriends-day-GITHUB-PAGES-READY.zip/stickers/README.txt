sad.webp = wrong-password page sticker.
no-sticker.gif = NO page sticker.
Replace either file if you want to customize the stickers later.
